<?php
/**
 * the base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** MySQL database username */
define( 'DB_USER', 'db-username' );

/** MySQL database password */
define( 'DB_PASSWORD', 'db-password' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'AyMVNhY;( !IJn-/9]D4xUg0*M6?~ZDm[T_[COc^+G($@:O c3q8<5tC]C@aPP6v' );
define( 'SECURE_AUTH_KEY',  '3j1Wuo$IBzWf~Cu7kN>({ %d[y^ok!`9+*$ruQ:=;t(wUhQ]K.w{V(|thN Le|`-' );
define( 'LOGGED_IN_KEY',    '6A2)`z.y%Ro3}V; :#7ndC-yheZ4~&qmTi[(DlDz&{<i%xk~yYz>~C92@v=;u-S&' );
define( 'NONCE_KEY',        'F5sZRnQ,j?BNNJXZ2xVe,!Jyr0;<OZ_zT;Ij_e%n]`yTIg76jTW]$hh646w#F0p%' );
define( 'AUTH_SALT',        '.9Lc0$B:*cW^]M8|a)scRcECP#745d[Q(4|o7>-FE`SJW)= TK(i|F*sN0Nr]SKo' );
define( 'SECURE_AUTH_SALT', 'ov5]P/32|tWX/P`E4ilswdqPAk-J%!xOUN11#<OrF=t2b{)d>-b|kl,WH _^F6D=' );
define( 'LOGGED_IN_SALT',   'eZvC6RS[u6UIcE<#UE:dD`8pbZ6<SB72b-^L$pGdy*LA^6>><(APCv@@<1L3@=P#' );
define( 'NONCE_SALT',       'q1]);UJdr(^2z68t6@`cb,:77h9!h|f}D&p:(?+jrNqzfQBq/tmq06UB~D0|~m5e' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );

